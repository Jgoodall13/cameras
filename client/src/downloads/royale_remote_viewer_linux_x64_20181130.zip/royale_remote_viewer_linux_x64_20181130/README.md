To run the Royale viewer, please execute royaleviewer.sh, it will 
automatically set the right path to the necessary libraries.

Execute the following command:
./royaleviewer.sh

The script sets the environment to use the libraries for Royale and Qt5.4.


