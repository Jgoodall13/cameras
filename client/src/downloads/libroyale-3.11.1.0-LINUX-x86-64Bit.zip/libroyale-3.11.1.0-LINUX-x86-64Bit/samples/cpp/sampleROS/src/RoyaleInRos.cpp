/****************************************************************************\
 * Copyright (C) 2017 pmdtechnologies ag
 *
 * THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY
 * KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
 * PARTICULAR PURPOSE.
 *
 \****************************************************************************/

#include <RoyaleInRos.hpp>

#include <sensor_msgs/PointCloud2.h>
#include <sensor_msgs/point_cloud2_iterator.h>
#include <sensor_msgs/Image.h>
#include <sensor_msgs/image_encodings.h>

using namespace std;
using namespace royale;

RoyaleInRos::RoyaleInRos () :
    IDepthDataListener(),
    IExposureListener(),
    m_cameraDevice (nullptr),
    m_server (m_lockServer)
{
    m_frames = 0;
    m_streamCount = 0;
}

RoyaleInRos::~RoyaleInRos()
{
    stop ();
}

void RoyaleInRos::onInit()
{
    // Retrieve the handle of the current node
    auto nodeHandle = getMTPrivateNodeHandle ();

    // Advertise our point cloud topic
    m_publisherCameraInfo = nodeHandle.advertise<sensor_msgs::CameraInfo> ("camera_info", 1);
    m_publisherCloud = nodeHandle.advertise<sensor_msgs::PointCloud2> ("point_cloud", 1);
    m_publisherDepth = nodeHandle.advertise<sensor_msgs::Image> ("depth_image", 1);
    m_publisherGray = nodeHandle.advertise<sensor_msgs::Image> ("gray_image", 1);

    start ();
}

void RoyaleInRos::start()
{
    m_fpsProcess =  thread (&RoyaleInRos::fpsUpdate, this);

    // Create a camera manager and query available cameras
    CameraManager manager;
    Vector<String> cameraList (manager.getConnectedCameraList());

    if (cameraList.empty ())
    {
        NODELET_ERROR_STREAM ("No suitable cameras found!");
        return;
    }

    // Create the first camera that was found, register a data listener
    // and start the capturing
    m_cameraDevice = manager.createCamera (cameraList[0]);

    String cameraName;
    m_cameraDevice->getCameraName (cameraName);
    NODELET_INFO_STREAM ("Opened camera : " << cameraName.c_str());

    if (m_cameraDevice->initialize() != CameraStatus::SUCCESS)
    {
        NODELET_ERROR_STREAM ("Error initializing the camera!");
        return;
    }

    if (!setCameraInfo())
    {
        NODELET_ERROR_STREAM ("Couldn't create camera info!");
        return;
    }

    if (m_cameraDevice->registerExposureListener (this) != CameraStatus::SUCCESS)
    {
        NODELET_ERROR_STREAM ("Couldn't register exposure listener!");
        return;
    }

    if (m_cameraDevice->registerDataListener (this) != CameraStatus::SUCCESS)
    {
        NODELET_ERROR_STREAM ("Couldn't register data listener!");
        return;
    }

    if (m_cameraDevice->startCapture() != CameraStatus::SUCCESS)
    {
        NODELET_ERROR_STREAM ("Error starting camera capture!");
        return;
    }

    initializeGUI();
}

void RoyaleInRos::stop()
{
    // Close the camera
    if (m_cameraDevice &&
            m_cameraDevice->stopCapture() != CameraStatus::SUCCESS)
    {
        NODELET_ERROR_STREAM ("Error stopping camera capture!");
        return;
    }

    m_fpsProcess.join();
}

void RoyaleInRos::onNewData (const DepthData *data)
{
    m_frames++;

    // Create a standard header
    std_msgs::Header header;
    header.frame_id = "royale_camera_optical_frame";
    header.seq = 0;
    header.stamp.fromNSec (chrono::duration_cast<chrono::nanoseconds> (data->timeStamp).count());

    // Create camera info message
    sensor_msgs::CameraInfoPtr msgCameraInfo = sensor_msgs::CameraInfoPtr (new sensor_msgs::CameraInfo);

    *msgCameraInfo = m_cameraInfo;
    msgCameraInfo->header = header;
    msgCameraInfo->height = data->height;
    msgCameraInfo->width = data->width;

    // Create point cloud message ...
    sensor_msgs::PointCloud2Ptr msgPointCloud = sensor_msgs::PointCloud2Ptr (new sensor_msgs::PointCloud2);

    // ... where we want to save x,y,z
    msgPointCloud->fields.resize (3);

    msgPointCloud->fields[0].name = "x";
    msgPointCloud->fields[0].offset = 0;
    msgPointCloud->fields[0].datatype = sensor_msgs::PointField::FLOAT32;
    msgPointCloud->fields[0].count = 1;

    msgPointCloud->fields[1].name = "y";
    msgPointCloud->fields[1].offset = static_cast<uint32_t> (sizeof (float));
    msgPointCloud->fields[1].datatype = sensor_msgs::PointField::FLOAT32;
    msgPointCloud->fields[1].count = 1;

    msgPointCloud->fields[2].name = "z";
    msgPointCloud->fields[2].offset = 2u * static_cast<uint32_t> (sizeof (float));
    msgPointCloud->fields[2].datatype = sensor_msgs::PointField::FLOAT32;
    msgPointCloud->fields[2].count = 1;

    msgPointCloud->header = header;
    msgPointCloud->width = data->width;
    msgPointCloud->height = data->height;
    msgPointCloud->is_bigendian = false;
    msgPointCloud->is_dense = false;
    msgPointCloud->point_step = static_cast<uint32_t> (3 * sizeof (float));
    msgPointCloud->row_step = static_cast<uint32_t> (3 * sizeof (float) * data->width);

    // Reserve space for the actual data
    msgPointCloud->data.resize (3 * sizeof (float) * data->points.size());

    // Create a point cloud modifier
    sensor_msgs::PointCloud2Modifier modifier (*msgPointCloud);
    modifier.setPointCloud2FieldsByString (1, "xyz");

    // Create iterators for the three fields in our point cloud
    sensor_msgs::PointCloud2Iterator<float> iterX (*msgPointCloud, "x");
    sensor_msgs::PointCloud2Iterator<float> iterY (*msgPointCloud, "y");
    sensor_msgs::PointCloud2Iterator<float> iterZ (*msgPointCloud, "z");

    // Create Depth Image message
    sensor_msgs::ImagePtr msgDepthImage = sensor_msgs::ImagePtr (new sensor_msgs::Image);

    msgDepthImage->header = header;
    msgDepthImage->width = data->width;
    msgDepthImage->height = data->height;
    msgDepthImage->is_bigendian = false;
    msgDepthImage->encoding = sensor_msgs::image_encodings::TYPE_32FC1;
    msgDepthImage->step = static_cast<uint32_t> (sizeof (float) * data->width);
    msgDepthImage->data.resize (sizeof (float) * data->points.size());

    float *iterDepth = (float *) &msgDepthImage->data[0];

    // Create Depth Image message
    sensor_msgs::ImagePtr msgGrayImage = sensor_msgs::ImagePtr (new sensor_msgs::Image);

    msgGrayImage->header = header;
    msgGrayImage->width = data->width;
    msgGrayImage->height = data->height;
    msgGrayImage->is_bigendian = false;
    msgGrayImage->encoding = sensor_msgs::image_encodings::MONO16;
    msgGrayImage->step = static_cast<uint32_t> (sizeof (uint16_t) * data->width);
    msgGrayImage->data.resize (sizeof (uint16_t) * data->points.size());

    uint16_t *iterGray = (uint16_t *) &msgGrayImage->data[0];

    // Iterate over all the points we received in the callback
    for (auto currentPoint : data->points)
    {
        if (currentPoint.depthConfidence > 0)
        {
            *iterX = currentPoint.x;
            *iterY = currentPoint.y;
            *iterZ = currentPoint.z;
            *iterDepth = currentPoint.z;
        }
        else
        {
            // If the confidence is 0 set this point to NaN
            // (according to http://www.ros.org/reps/rep-0117.html)
            *iterX = *iterY = *iterZ = numeric_limits<float>::quiet_NaN();
            *iterDepth = 0.0f;
        }

        // Set divisor of gray image to adjust the brightness
        uint16_t clampedVal = std::min (static_cast<uint16_t> (m_config.gray_divisor), currentPoint.grayValue);
        int newGrayValue = std::min (254, static_cast<int> (254 * 1.f * (float) clampedVal / (float) m_config.gray_divisor));

        if (newGrayValue < 0)
        {
            newGrayValue = 0;
        }

        *iterGray = static_cast<uint16_t> (newGrayValue);

        ++iterX;
        ++iterY;
        ++iterZ;
        ++iterDepth;
        ++iterGray;
    }

    // Publish the messages
    m_publisherCameraInfo.publish (msgCameraInfo);
    m_publisherCloud.publish (msgPointCloud);
    m_publisherDepth.publish (msgDepthImage);
    m_publisherGray.publish (msgGrayImage);
}

void RoyaleInRos::onNewExposure (const uint32_t newExposureTime)
{
    if (m_config.exposure_time == (int) newExposureTime)
    {
        return;
    }

    m_config.exposure_time = (int) newExposureTime;
    m_server.updateConfig (m_config);
}

bool RoyaleInRos::setUseCase (const size_t id)
{
    Vector<String> useCases;
    m_cameraDevice->getUseCases (useCases);
    String useCase;
    m_cameraDevice->getCurrentUseCase (useCase);

    if (useCases[id] == useCase)
    {
        return true;
    }

    if (m_cameraDevice->setUseCase (useCases[id]) != CameraStatus::SUCCESS)
    {
        NODELET_ERROR_STREAM ("Couldn't set use case!");
        return false;
    }
    else
    {
        NODELET_INFO_STREAM ("use case changed to: " << useCases[id]);
        m_config.use_case_name = useCases[id].toStdString();
        m_server.updateConfig (m_config);

        if (m_cameraDevice->getNumberOfStreams (useCases[id], m_streamCount) != CameraStatus::SUCCESS)
        {
            NODELET_ERROR_STREAM ("Error retrieving the number of streams for use case " << useCases[id]);
            return false;
        }
        else
        {
            if (m_streamCount > 1)
            {
                NODELET_WARN_STREAM ("Mixed mode is not supported currently!");
            }
            return true;
        }
    }
}

bool RoyaleInRos::setExposureMode (const bool isAutomatic)
{
    ExposureMode newMode;
    if (isAutomatic)
    {
        newMode = ExposureMode::AUTOMATIC;
    }
    else
    {
        newMode = ExposureMode::MANUAL;
    }
    ExposureMode exposureMode;
    m_cameraDevice->getExposureMode (exposureMode);

    if (newMode == exposureMode)
    {
        return true;
    }
    else
    {
        if (m_cameraDevice->setExposureMode (newMode) != CameraStatus::SUCCESS)
        {
            NODELET_ERROR_STREAM ("Couldn't set operation mode!");
            return false;
        }
        else
        {
            NODELET_INFO_STREAM ("exposure mode changed to: " << (isAutomatic ? "automatic" : "manual"));
            return true;
        }
    }
}

bool RoyaleInRos::setExposureTime (const uint32_t exposureTime)
{
    Pair<uint32_t, uint32_t> limits;
    m_cameraDevice->getExposureLimits (limits);

    if (exposureTime < limits.first || exposureTime > limits.second)
    {
        NODELET_WARN_STREAM ("Exposure time outside of limits!");
        return false;
    }

    if (m_cameraDevice->setExposureTime (exposureTime) != CameraStatus::SUCCESS)
    {
        NODELET_WARN_STREAM ("Couldn't set exposure time!");
        return false;
    }
    else
    {
        return true;
    }
}

bool RoyaleInRos::setCameraInfo()
{
    LensParameters lensParams;
    if ( (m_cameraDevice->getLensParameters (lensParams) == CameraStatus::SUCCESS))
    {
        if (lensParams.distortionRadial.size() != 3)
        {
            NODELET_ERROR_STREAM ("Unknown distortion model!");
            return false;
        }
        else
        {
            m_cameraInfo.distortion_model = "plumb_bob";
            m_cameraInfo.D.resize (5);
            m_cameraInfo.D[0] = lensParams.distortionRadial[0];
            m_cameraInfo.D[1] = lensParams.distortionRadial[1];
            m_cameraInfo.D[2] = lensParams.distortionTangential.first;
            m_cameraInfo.D[3] = lensParams.distortionTangential.second;
            m_cameraInfo.D[4] = lensParams.distortionRadial[2];
        }

        m_cameraInfo.K[0] = lensParams.focalLength.first;
        m_cameraInfo.K[1] = 0;
        m_cameraInfo.K[2] = lensParams.principalPoint.first;
        m_cameraInfo.K[3] = 0;
        m_cameraInfo.K[4] = lensParams.focalLength.second;
        m_cameraInfo.K[5] = lensParams.principalPoint.second;
        m_cameraInfo.K[6] = 0;
        m_cameraInfo.K[7] = 0;
        m_cameraInfo.K[8] = 1;

        m_cameraInfo.R[0] = 1;
        m_cameraInfo.R[1] = 0;
        m_cameraInfo.R[2] = 0;
        m_cameraInfo.R[3] = 0;
        m_cameraInfo.R[4] = 1;
        m_cameraInfo.R[5] = 0;
        m_cameraInfo.R[6] = 0;
        m_cameraInfo.R[7] = 0;
        m_cameraInfo.R[8] = 1;

        m_cameraInfo.P[0] = lensParams.focalLength.first;
        m_cameraInfo.P[1] = 0;
        m_cameraInfo.P[2] = lensParams.principalPoint.first;
        m_cameraInfo.P[3] = 0;
        m_cameraInfo.P[4] = 0;
        m_cameraInfo.P[5] = lensParams.focalLength.second;
        m_cameraInfo.P[6] = lensParams.principalPoint.second;
        m_cameraInfo.P[7] = 0;
        m_cameraInfo.P[8] = 0;
        m_cameraInfo.P[9] = 0;
        m_cameraInfo.P[10] = 1;
        m_cameraInfo.P[11] = 0;

        return true;
    }
    else
    {
        NODELET_ERROR_STREAM ("Couldn't get lens parameters!");
        return false;
    }
}

void RoyaleInRos::initializeGUI()
{
    m_configMin.exposure_time = 1;
    m_configMin.gray_divisor = 1;
    m_server.setConfigMin (m_configMin);

    Vector<String> useCases;
    m_cameraDevice->getUseCases (useCases);
    m_configMax.use_case_id = (int) (useCases.size() - 1);

    m_configMax.exposure_time = MAX_EX_TIME;
    m_configMax.gray_divisor = 2000;
    m_server.setConfigMax (m_configMax);

    Pair<uint32_t, uint32_t> limits;
    m_cameraDevice->getExposureLimits (limits);
    m_configMin.exposure_time = limits.first;
    m_configMax.exposure_time = limits.second;

    String useCase;
    m_cameraDevice->getCurrentUseCase (useCase);
    m_config.use_case_name = useCase.toStdString();
    m_config.use_case_id = 0;
    m_config.auto_exposure = false;
    m_config.exposure_time = max (min (MAX_EX_TIME, m_configMax.exposure_time), m_configMin.exposure_time);
    m_config.gray_divisor = 100;
    m_server.setConfigDefault (m_config);
    m_server.updateConfig (m_config);

    dynamic_reconfigure::Server<royale_tools::camera_driverConfig>::CallbackType f;
    f = std::bind (&RoyaleInRos::callbackGUI, this, std::placeholders::_1, std::placeholders::_2);
    m_server.setCallback (f);
}

void RoyaleInRos::callbackGUI (royale_tools::camera_driverConfig &config, uint32_t level)
{
    if (level == 0xFFFFFFFF)
    {
        return;
    }

    if (level & 0x01)
    {
        if (setUseCase ( (size_t) config.use_case_id))
        {
            m_config.use_case_id = config.use_case_id;

            if (m_config.auto_exposure)
            {
                m_config.auto_exposure = false;
                NODELET_INFO_STREAM ("exposure mode changed to: manual");
            }

            if (m_streamCount == 1)
            {
                Pair<uint32_t, uint32_t> limits;
                m_cameraDevice->getExposureLimits (limits);
                m_configMin.exposure_time = limits.first;
                m_configMax.exposure_time = limits.second;
                NODELET_INFO_STREAM ("current exposure limits: " << limits.first << " / " << limits.second);
            }
        }
    }

    if (level & 0x02)
    {
        ExposureMode exposureMode;
        m_cameraDevice->getExposureMode (exposureMode);
        bool isCapturing = false;
        m_cameraDevice->isCapturing (isCapturing);
        if (isCapturing && exposureMode != ExposureMode::AUTOMATIC && setExposureTime ( (uint32_t) config.exposure_time))
        {
            m_config.exposure_time = config.exposure_time;
        }
    }

    if (level & 0x04)
    {
        if (setExposureMode (config.auto_exposure))
        {
            m_config.auto_exposure = config.auto_exposure;
            m_config.exposure_time = config.exposure_time;
        }
    }

    if (level & 0x08)
    {
        m_config.gray_divisor = config.gray_divisor;
    }
}

void RoyaleInRos::fpsUpdate()
{
    while (ros::ok())
    {
        this_thread::sleep_for (chrono::seconds (1));

        m_config.fps = to_string (m_frames);
        m_server.updateConfig (m_config);
        m_frames = 0;
    }
}

PLUGINLIB_EXPORT_CLASS (RoyaleInRos, nodelet::Nodelet)

