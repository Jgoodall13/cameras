/****************************************************************************\
 * Copyright (C) 2017 pmdtechnologies ag
 *
 * THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY
 * KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
 * PARTICULAR PURPOSE.
 *
 \****************************************************************************/

#include <royale.hpp>

#include <thread>

#include <ros/ros.h>
#include <sensor_msgs/CameraInfo.h>
#include <nodelet/nodelet.h>
#include <pluginlib/class_list_macros.h>

#include <dynamic_reconfigure/server.h>
#include <royale_in_ros/camera_driverConfig.h>

#define MAX_EX_TIME 2000 //max exposure time for gui

class RoyaleInRos :
    public nodelet::Nodelet, public royale::IDepthDataListener, public royale::IExposureListener
{
public:
    RoyaleInRos ();
    ~RoyaleInRos();

    // Overridden from Nodelet
    void onInit() override;

    // Starting and stopping the camera
    void start();
    void stop();

private:
    // The callback of dynamic reconfigure
    void callbackGUI (royale_tools::camera_driverConfig &config, uint32_t level);

    // Called by Royale for every new frame
    void onNewData (const royale::DepthData *data) override;

    // Will be called when the newly calculated exposure time deviates from currently set exposure time of the current UseCase
    void onNewExposure (const uint32_t newExposureTime) override;

    // Set the use case, return true if the setting is successful, otherwise false
    bool setUseCase (const size_t id);

    // Set the exposure mode, return true if the setting is successful, otherwise false
    bool setExposureMode (const bool isAutomatic);

    // Set the exposure time, return true if the setting is successful, otherwise false
    bool setExposureTime (const uint32_t exposureTime);

    // Create cameraInfo, return true if the setting is successful, otherwise false
    bool setCameraInfo();

    // Initialize the values and the range of values for dynamic reconfigure
    void initializeGUI();

    // Calculate and display the FPS
    void fpsUpdate();

    sensor_msgs::CameraInfo m_cameraInfo;

    ros::Publisher m_publisherCameraInfo;
    ros::Publisher m_publisherCloud;
    ros::Publisher m_publisherDepth;
    ros::Publisher m_publisherGray;
    std::unique_ptr<royale::ICameraDevice> m_cameraDevice;

    boost::recursive_mutex             m_lockServer;
    dynamic_reconfigure::Server<royale_tools::camera_driverConfig> m_server;
    royale_tools::camera_driverConfig  m_configMin;
    royale_tools::camera_driverConfig  m_configMax;
    royale_tools::camera_driverConfig  m_config;

    std::thread   m_fpsProcess;
    uint64_t      m_frames;
    uint32_t      m_streamCount;
};

